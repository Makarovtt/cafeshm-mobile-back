require('./dist/main.js')
